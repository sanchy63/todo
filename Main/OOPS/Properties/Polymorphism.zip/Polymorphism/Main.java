package Properties.Polymorphism;

public class Main {
    public static void main(String[] args) {
        Shapes shape=new Shapes();
        Circle circle=new Circle();
        square square=new square();
        Triangle triangle=new Triangle();
        circle.area();
    }
}
