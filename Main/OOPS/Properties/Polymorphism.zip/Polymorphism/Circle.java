package Properties.Polymorphism;

public class Circle extends Shapes{
     @Override
    public void area(){
        System.out.println("I am in Circle");
    }
}
