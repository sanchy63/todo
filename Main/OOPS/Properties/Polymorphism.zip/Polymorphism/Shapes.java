package Properties.Polymorphism;

public class Shapes {
    public void area(){
        System.out.println("I am in shapes");
    }
}
