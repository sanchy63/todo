package Properties.Polymorphism;

public class Triangle {
    public void area(){
        System.out.println("I am in Triangle");
    }
}
